# MQTT-Client
 MQTT-Client in C

MQTT Client Using Eclipse Paho Library

# Linux/Mac

	# for Eclipse paho-mqtt lib dependency

	The C client can be built for Linux/Unix/Mac with make and gcc. To build:

	git clone https://github.com/eclipse/paho.mqtt.c.git
	cd org.eclipse.paho.mqtt.c.git
	make
	To install:

	sudo make install


	# for json lib dependency

	sudo apt install libjson-c-dev 
